CSS Positioning and Formatting Exercise
David Simkins, IGME110.03, Fall 2018

This is a plain text document. A readme.txt is not often included in websites specifically, but it is often included in collections of files you download. It often gives credit to authors, and may include a change log or other helpful information. You will add a readme.txt to your website, like this one. In it you should include the following:

    1. The title of your website
    2. Your name, class & section (IGME110.03), and semester (Fall 2018)
    3. The URL for your website where I can find it online
    4. Any comments you have that might help me understand your work better.
    
You may have other notes or information here, but all other information should be clearly seperated from your responses.
